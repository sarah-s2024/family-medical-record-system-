import React from 'react';
import { Layout, Menu } from 'antd';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import {
  FileTextOutlined,
  UploadOutlined,
  UserOutlined,
  BarChartOutlined,
  HomeOutlined,
  BugOutlined
} from '@ant-design/icons';

import Dashboard from './pages/Dashboard';
import PDFUpload from './pages/PDFUpload';
import ManualEntry from './pages/ManualEntry';
import Records from './pages/Records';
import Reports from './pages/Reports';
import Patients from './pages/Patients';
import PDFTest from './PDFTest';

const { Header, Sider, Content } = Layout;

const AppLayout = () => {
  const location = useLocation();
  
  const menuItems = [
    {
      key: '/',
      icon: <HomeOutlined />,
      label: <Link to="/">仪表板</Link>,
    },
    {
      key: '/upload',
      icon: <UploadOutlined />,
      label: <Link to="/upload">PDF上传</Link>,
    },
    {
      key: '/manual',
      icon: <FileTextOutlined />,
      label: <Link to="/manual">手动录入</Link>,
    },
    {
      key: '/records',
      icon: <FileTextOutlined />,
      label: <Link to="/records">医疗记录</Link>,
    },
    {
      key: '/reports',
      icon: <BarChartOutlined />,
      label: <Link to="/reports">疾病报告</Link>,
    },
    {
      key: '/patients',
      icon: <UserOutlined />,
      label: <Link to="/patients">家庭成员管理</Link>,
    },
    {
      key: '/pdf-test',
      icon: <BugOutlined />,
      label: <Link to="/pdf-test">PDF测试</Link>,
    },
  ];

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Header style={{ background: '#1890ff', padding: '0 24px' }}>
        <div style={{ color: 'white', fontSize: '20px', fontWeight: 'bold' }}>
          医疗数据管理系统
        </div>
      </Header>
      <Layout>
        <Sider width={200} style={{ background: '#fff' }}>
          <Menu
            mode="inline"
            selectedKeys={[location.pathname]}
            style={{ height: '100%', borderRight: 0 }}
            items={menuItems}
          />
        </Sider>
        <Layout style={{ padding: '0 24px 24px' }}>
          <Content
            style={{
              background: '#fff',
              padding: 24,
              margin: 0,
              minHeight: 280,
              borderRadius: '8px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
            }}
          >
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/upload" element={<PDFUpload />} />
              <Route path="/manual" element={<ManualEntry />} />
              <Route path="/records" element={<Records />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/patients" element={<Patients />} />
              <Route path="/pdf-test" element={<PDFTest />} />
            </Routes>
          </Content>
        </Layout>
      </Layout>
    </Layout>
  );
};

function App() {
  return <AppLayout />;
}

export default App;
